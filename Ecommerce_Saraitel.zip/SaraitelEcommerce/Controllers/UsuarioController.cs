﻿using Microsoft.AspNetCore.Mvc;
using Saraitel.API.Interfaces;

namespace Saraitel.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioService _usuarioService;

        public UsuarioController(IUsuarioService usuarioService)
        {
            _usuarioService = usuarioService;
        }

        [HttpPost("login")]
        public IActionResult Login(
            [FromQuery] string correo,
            [FromQuery] string contrasena)
        {
            var resultado = _usuarioService.IniciarSesion(correo, contrasena);

            if (!resultado.StartsWith("Bienvenido"))
                return BadRequest(resultado);

            var usuario = _usuarioService.ObtenerUsuarioPorCorreo(correo);

            return Ok(new
            {
                mensaje = resultado,
                idUsuario = usuario?.IdUsuario ?? 0,
                nombre = usuario?.Nombre ?? "",
                rol = usuario?.Rol ?? "Cliente"
            });
        }

        [HttpPost("registro")]
        public IActionResult RegistrarUsuario(
            string nombre,
            string correo,
            string telefono,
            string contrasena,
            string direccion = "")
        {
            var resultado = _usuarioService.RegistrarUsuario(
                "cliente",
                nombre,
                correo,
                telefono,
                contrasena,
                direccion);

            if (resultado.Contains("correctamente"))
                return Ok(resultado);

            return BadRequest(resultado);
        }

        [HttpGet("correo/{correo}")]
        public IActionResult ObtenerPorCorreo(string correo)
        {
            var usuario = _usuarioService.ObtenerUsuarioPorCorreo(correo);

            if (usuario == null)
                return NotFound("Usuario no encontrado");

            return Ok(usuario);
        }

        [HttpGet]
        public IActionResult ObtenerUsuarios()
        {
            var usuarios = _usuarioService.ObtenerUsuarios();
            return Ok(usuarios);
        }

        [HttpGet("{id:int}")]
        public IActionResult ObtenerPorId(int id)
        {
            var usuario = _usuarioService.ObtenerUsuarioPorId(id);

            if (usuario == null)
                return NotFound("Usuario no encontrado");

            return Ok(usuario);
        }
    }
}