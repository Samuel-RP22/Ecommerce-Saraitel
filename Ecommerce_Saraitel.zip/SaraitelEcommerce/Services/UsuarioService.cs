﻿using Saraitel.API.Interfaces;
using Saraitel.Datos.Repositories;
using Saraitel.Entidades;
using Saraitel.Entidades.Factories;

namespace Saraitel.API.Services
{
    public class UsuarioService : IUsuarioService
    {
        private readonly
            UsuarioRepository _usuarioRepository;

        private static int
            _intentosFallidos = 0;

        public UsuarioService()
        {
            _usuarioRepository = new UsuarioRepository();
        }

        public List<Usuario>
            ObtenerUsuarios()
        {
            return _usuarioRepository.ObtenerUsuarios();
        }

        public Usuario?
            ObtenerUsuarioPorId(int id)
        {
            return _usuarioRepository.ObtenerUsuarioPorId(id);
        }

        public Usuario? ObtenerUsuarioPorCorreo(string correo)
        {
            if (string.IsNullOrEmpty(correo)) return null;
            return ObtenerUsuarios().FirstOrDefault(u => u.Correo.Trim().ToLower() == correo.Trim().ToLower());
        }

        public string RegistrarUsuario(string rol,string nombre,string correo,string telefono,string contrasena,string direccion = "")
        {
            var usuarioExistente = _usuarioRepository.ObtenerUsuarioPorCorreo(correo);

            if (usuarioExistente!= null)
            {
                return
                    "El correo ya está registrado";
            }

            int nuevoId =ObtenerUsuarios().Any()? 
                ObtenerUsuarios().Max(u =>u.IdUsuario) + 1: 1;

            Usuario usuario = UsuarioFactory.CrearUsuario(
                    rol,
                    nuevoId,
                    nombre,
                    correo,
                    telefono,
                    contrasena,
                    direccion);
            _usuarioRepository.AgregarUsuario(usuario);

            return
                "Usuario registrado correctamente";
        }

        public string IniciarSesion(string correo, string contrasena)
        {
            var usuario = ObtenerUsuarioPorCorreo(correo);
            if (usuario == null)
            {
                return "Usuario no encontrado";
            }
            if (usuario.Contrasena != contrasena)
            {
                _intentosFallidos++;

                return $"Contrasena incorrecta. Intentos restantes: {3 - _intentosFallidos}";
            }
            _intentosFallidos = 0;
            return $"Bienvenido {usuario.Nombre} ({usuario.Rol})";
        }
    }
}