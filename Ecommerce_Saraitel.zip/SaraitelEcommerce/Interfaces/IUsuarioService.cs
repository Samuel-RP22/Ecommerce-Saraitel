﻿using Saraitel.Entidades;

namespace Saraitel.API.Interfaces
{
    public interface IUsuarioService
    {
        List<Usuario> ObtenerUsuarios();

        Usuario? ObtenerUsuarioPorId(int id);

        Usuario? ObtenerUsuarioPorCorreo(string correo);

        string RegistrarUsuario(
            string rol,
            string nombre,
            string correo,
            string telefono,
            string Contrasena,
            string direccion = "");

        string IniciarSesion(
            string correo,
            string Contrasena);
    }
}